# Professional Blog - Complete Setup Guide

Your professional blog now includes **dark mode**, **markdown support**, **SEO optimization**, and **newsletter signup**.

---

## What's New

✅ **Dark Mode Toggle** — Readers can switch between light and dark themes  
✅ **Markdown Support** — Write posts with proper formatting, code blocks, lists  
✅ **SEO Meta Tags** — Meta descriptions, Open Graph, sitemap.xml  
✅ **Newsletter Signup** — Capture emails from interested readers  
✅ **Professional Styling** — Polished typography and color scheme  
✅ **Analytics Ready** — Setup for Google Analytics integration  

---

## Installation

### 1. Backend Setup

```bash
# Create project folder
mkdir professional-blog && cd professional-blog

# Initialize Node
npm init -y

# Install dependencies
npm install express sqlite3 cors

# Create server-professional.js with the code provided

# Run backend
node server-professional.js
```

Backend runs on `http://localhost:5000` with sitemap at `/sitemap.xml`

### 2. Frontend Setup

```bash
# Create React app
npx create-react-app blog-frontend
cd blog-frontend

# Install markdown renderer
npm install react-markdown

# Replace src/App.js with Blog-Professional.jsx

# Start frontend
npm start
```

Frontend runs on `http://localhost:3000`

---

## Features

### Public Features

**Homepage**
- Hero section with compelling headline
- Featured newsletter signup
- Post list with categories, reading time
- Light/dark mode toggle (top right)

**Individual Post Pages**
- Full markdown rendering (headers, bold, code blocks, lists)
- Reading time estimate
- Share-ready SEO meta tags
- Category badge

**Dark Mode**
- Persistent (saved to localStorage)
- Smooth transitions
- Optimized colors for readability
- Professional appearance in both modes

### Admin Features

**Write Panel** (`/write`)
- Create posts with markdown content
- SEO description field (160 chars)
- Category organization
- Edit/delete existing posts
- Real-time preview on homepage

**Newsletter**
- Email collection form
- Simple confirmation message
- (Ready to connect to SendGrid/Mailchimp)

---

## Markdown Syntax

Write posts using standard markdown:

```markdown
# Heading 1
## Heading 2

**Bold text**
*Italic text*

- Bullet list
- Another item

1. Numbered list
2. Second item

[Link text](https://example.com)

`inline code`

\`\`\`javascript
// Code block with syntax highlighting
const x = "hello";
\`\`\`
```

---

## SEO Setup

### 1. Sitemap
Automatically generated at `/sitemap.xml` with all posts and dates.
Submit to Google Search Console and Bing Webmaster Tools.

### 2. Meta Tags
Each post includes:
- Custom title
- SEO description (your input)
- Open Graph tags for social sharing
- Canonical URLs (add to frontend)

### 3. Performance
- Lazy load images (add to future updates)
- Minify CSS/JS
- Use CDN for static assets

### 4. SSL/HTTPS
- Essential for ranking
- Use Let's Encrypt (free)
- Automatic with Vercel

---

## Deployment

### Option 1: Vercel + Railway (Recommended)

**Frontend (Vercel)**
```bash
# Push repo to GitHub
# Connect to Vercel
# Auto-deploys on push
```

**Backend (Railway)**
```bash
# Push repo to GitHub
# Connect to Railway
# Get production URL
# Update API_URL in frontend
```

**Update frontend API:**
```javascript
const API = 'https://your-railway-url.com/api';
```

### Option 2: Single VPS (DigitalOcean, Linode)
- Deploy both on same server
- Use PM2 for process management
- Nginx as reverse proxy
- Auto-HTTPS with Certbot

---

## Next Steps

1. **Add Google Analytics**
   - Create account at analytics.google.com
   - Add tracking ID to `<head>`

2. **Connect Newsletter**
   - Integrate Mailchimp or SendGrid
   - Send confirmation email
   - Store emails in database

3. **Custom Domain**
   - Buy domain (Namecheap, GoDaddy)
   - Point DNS to Vercel
   - Setup SSL certificate

4. **Social Sharing**
   - Add Twitter/LinkedIn buttons
   - Optimize preview images
   - Add breadcrumb schema

5. **Comments System**
   - Integrate Disqus or Utterances
   - Moderate user feedback

6. **Email Notifications**
   - Send admin alerts on new comments
   - Automated "new post" emails to subscribers

---

## Performance Checklist

- [ ] Enable gzip compression
- [ ] Optimize images
- [ ] Minify JS/CSS
- [ ] Use CDN for assets
- [ ] Cache static files
- [ ] Monitor Core Web Vitals
- [ ] Test on mobile devices
- [ ] Setup 404 error page

---

## Environment Variables

Create `.env` file (backend):
```
DATABASE_URL=./blog.db
MAIL_API_KEY=your_mailchimp_key
ANALYTICS_ID=your_google_analytics_id
NODE_ENV=production
```

---

## Troubleshooting

**Dark mode not working?**
- Check localStorage in browser DevTools
- Clear cache and reload

**Markdown not rendering?**
- Ensure react-markdown is installed
- Check syntax is valid

**API connection failed?**
- Verify backend is running on port 5000
- Check CORS settings
- Review browser console for errors

**Posts not saving?**
- Check database permissions
- Verify all required fields filled
- Check network tab in DevTools

---

## License & Credits

Built with React, Express.js, SQLite
- React Markdown: github.com/remarkjs/react-markdown
- Express: expressjs.com
- SQLite: sqlite.org

Ready to launch your professional blog! 🚀
