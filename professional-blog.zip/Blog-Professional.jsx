import { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';

const API = 'http://localhost:5000/api';

const ProfessionalBlog = () => {
  const [posts, setPosts] = useState([]);
  const [currentView, setCurrentView] = useState('home');
  const [selectedPost, setSelectedPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const [darkMode, setDarkMode] = useState(localStorage.getItem('darkMode') === 'true');
  const [email, setEmail] = useState('');
  const [subscribeMsg, setSubscribeMsg] = useState('');

  // Admin state
  const [adminForm, setAdminForm] = useState({ title: '', slug: '', excerpt: '', content: '', category: '', seoDescription: '' });
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchPosts();
    localStorage.setItem('darkMode', darkMode);
  }, [darkMode]);

  const fetchPosts = async () => {
    try {
      const res = await fetch(`${API}/posts`);
      const data = await res.json();
      setPosts(data);
      setLoading(false);
    } catch (err) {
      console.error('Failed to fetch posts:', err);
      setLoading(false);
    }
  };

  const fetchPost = async (slug) => {
    try {
      const res = await fetch(`${API}/posts/${slug}`);
      const data = await res.json();
      setSelectedPost(data);
      setCurrentView('post');
      // Update page title for SEO
      document.title = `${data.title} | Professional Blog`;
    } catch (err) {
      console.error('Failed to fetch post:', err);
    }
  };

  const handlePublish = async (e) => {
    e.preventDefault();
    if (!adminForm.title || !adminForm.slug || !adminForm.content) {
      alert('Please fill in all required fields');
      return;
    }

    try {
      if (editingId) {
        await fetch(`${API}/posts/${editingId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(adminForm),
        });
      } else {
        await fetch(`${API}/posts`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(adminForm),
        });
      }
      setAdminForm({ title: '', slug: '', excerpt: '', content: '', category: '', seoDescription: '' });
      setEditingId(null);
      fetchPosts();
      alert(editingId ? 'Post updated!' : 'Post published!');
    } catch (err) {
      console.error('Error saving post:', err);
    }
  };

  const handleEdit = (post) => {
    setAdminForm({
      title: post.title,
      slug: post.slug,
      excerpt: post.excerpt || '',
      content: post.content,
      category: post.category || '',
      seoDescription: post.seoDescription || '',
    });
    setEditingId(post.id);
  };

  const handleDelete = async (id) => {
    if (confirm('Delete this post?')) {
      try {
        await fetch(`${API}/posts/${id}`, { method: 'DELETE' });
        fetchPosts();
      } catch (err) {
        console.error('Error deleting post:', err);
      }
    }
  };

  const handleSubscribe = (e) => {
    e.preventDefault();
    if (email) {
      setSubscribeMsg('✓ Thanks for subscribing!');
      setEmail('');
      setTimeout(() => setSubscribeMsg(''), 3000);
    }
  };

  const readingTime = (content) => {
    const words = content.split(/\s+/).length;
    return Math.ceil(words / 200);
  };

  const formatDate = (dateStr) => {
    return new Date(dateStr).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  const getColors = () => ({
    bg: darkMode ? '#0f172a' : '#ffffff',
    text: darkMode ? '#f1f5f9' : '#1f2937',
    textSecondary: darkMode ? '#cbd5e1' : '#6b7280',
    border: darkMode ? '#1e293b' : '#e5e7eb',
    cardBg: darkMode ? '#1e293b' : '#f9fafb',
    accentBg: darkMode ? '#334155' : '#f0f4f8',
  });

  const colors = getColors();

  return (
    <div style={{ ...styles.container, background: colors.bg, color: colors.text }}>
      {/* Meta tags for SEO */}
      <head>
        <meta name="description" content="Professional insights on design, technology, and digital innovation." />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta property="og:type" content="website" />
        <meta property="og:title" content="Professional Blog" />
        <meta property="og:description" content="Thoughtful articles on design, tech, and strategy." />
      </head>

      {/* Header */}
      <header style={{ ...styles.header, borderBottomColor: colors.border, background: colors.bg }}>
        <div style={styles.headerContent}>
          <button
            onClick={() => { setCurrentView('home'); setSelectedPost(null); document.title = 'Professional Blog'; }}
            style={{ ...styles.logo, color: colors.text }}
          >
            <span style={{ fontWeight: 700, letterSpacing: '-0.02em' }}>BLOG</span>
          </button>
          <nav style={styles.nav}>
            <button
              onClick={() => setCurrentView('home')}
              style={{
                ...styles.navButton,
                color: currentView === 'home' ? colors.text : colors.textSecondary,
                borderBottom: currentView === 'home' ? `2px solid ${colors.text}` : 'none',
              }}
            >
              Home
            </button>
            <button
              onClick={() => setCurrentView('admin')}
              style={{
                ...styles.navButton,
                color: currentView === 'admin' ? colors.text : colors.textSecondary,
                borderBottom: currentView === 'admin' ? `2px solid ${colors.text}` : 'none',
              }}
            >
              Write
            </button>
            <button
              onClick={() => setDarkMode(!darkMode)}
              style={{
                ...styles.themeBtn,
                background: colors.accentBg,
                color: colors.text,
              }}
              title={darkMode ? 'Light mode' : 'Dark mode'}
            >
              {darkMode ? '☀️' : '🌙'}
            </button>
          </nav>
        </div>
      </header>

      <main style={styles.main}>
        {/* HOME VIEW */}
        {currentView === 'home' && (
          <div style={styles.homeView}>
            <div style={styles.hero}>
              <h1 style={{ ...styles.heroTitle, color: colors.text }}>
                Insights on Design & Technology
              </h1>
              <p style={{ ...styles.heroSubtitle, color: colors.textSecondary }}>
                In-depth articles on digital strategy, product design, and emerging tech trends
              </p>
            </div>

            {/* Newsletter Signup */}
            <div style={{ ...styles.newsletter, background: colors.accentBg, borderColor: colors.border }}>
              <h3 style={{ ...styles.newsletterTitle, color: colors.text }}>Stay Updated</h3>
              <p style={{ ...styles.newsletterText, color: colors.textSecondary }}>
                Get new articles delivered to your inbox
              </p>
              <form onSubmit={handleSubscribe} style={styles.newsletterForm}>
                <input
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  style={{
                    ...styles.emailInput,
                    background: colors.bg,
                    color: colors.text,
                    borderColor: colors.border,
                  }}
                  required
                />
                <button type="submit" style={styles.subscribeBtn}>
                  Subscribe
                </button>
              </form>
              {subscribeMsg && <p style={{ ...styles.subscribeMsg, color: colors.textSecondary }}>{subscribeMsg}</p>}
            </div>

            {loading ? (
              <p style={{ ...styles.loading, color: colors.textSecondary }}>Loading posts...</p>
            ) : posts.length === 0 ? (
              <p style={{ ...styles.empty, color: colors.textSecondary }}>No posts yet.</p>
            ) : (
              <div style={styles.postList}>
                {posts.map((post, idx) => (
                  <article
                    key={post.id}
                    style={{
                      ...styles.postCard,
                      background: colors.cardBg,
                      borderColor: colors.border,
                      marginBottom: idx < posts.length - 1 ? '2rem' : 0,
                    }}
                  >
                    <button
                      onClick={() => fetchPost(post.slug)}
                      style={{ ...styles.postTitle, color: colors.text }}
                    >
                      {post.title}
                    </button>
                    <div style={{ ...styles.postMeta, color: colors.textSecondary }}>
                      <span>{formatDate(post.createdAt)}</span>
                      <span> · </span>
                      <span>{readingTime(post.content)} min read</span>
                      {post.category && (
                        <>
                          <span> · </span>
                          <span style={{ ...styles.category, background: colors.accentBg, color: colors.text }}>
                            {post.category}
                          </span>
                        </>
                      )}
                    </div>
                    <p style={{ ...styles.postExcerpt, color: colors.textSecondary }}>
                      {post.excerpt || post.content.substring(0, 150) + '...'}
                    </p>
                  </article>
                ))}
              </div>
            )}
          </div>
        )}

        {/* POST VIEW */}
        {currentView === 'post' && selectedPost && (
          <article style={styles.fullPost}>
            <div style={{ ...styles.postHeader, borderColor: colors.border }}>
              <h1 style={{ ...styles.postFullTitle, color: colors.text }}>
                {selectedPost.title}
              </h1>
              <div style={{ ...styles.postMeta, color: colors.textSecondary }}>
                <span>{formatDate(selectedPost.createdAt)}</span>
                <span> · </span>
                <span>{readingTime(selectedPost.content)} min read</span>
                {selectedPost.category && (
                  <>
                    <span> · </span>
                    <span style={{ ...styles.category, background: colors.accentBg, color: colors.text }}>
                      {selectedPost.category}
                    </span>
                  </>
                )}
              </div>
            </div>
            <div style={{ ...styles.postContent, color: colors.text }}>
              <ReactMarkdown>{selectedPost.content}</ReactMarkdown>
            </div>
          </article>
        )}

        {/* ADMIN VIEW */}
        {currentView === 'admin' && (
          <div style={styles.adminView}>
            <h2 style={{ ...styles.adminTitle, color: colors.text }}>Publish New Article</h2>
            <form onSubmit={handlePublish} style={styles.form}>
              <div style={styles.formGroup}>
                <label style={{ ...styles.label, color: colors.text }}>Title *</label>
                <input
                  type="text"
                  value={adminForm.title}
                  onChange={(e) => setAdminForm({ ...adminForm, title: e.target.value })}
                  style={{
                    ...styles.input,
                    background: colors.cardBg,
                    color: colors.text,
                    borderColor: colors.border,
                  }}
                  placeholder="Article title"
                />
              </div>

              <div style={styles.formGroup}>
                <label style={{ ...styles.label, color: colors.text }}>Slug *</label>
                <input
                  type="text"
                  value={adminForm.slug}
                  onChange={(e) => setAdminForm({ ...adminForm, slug: e.target.value })}
                  style={{
                    ...styles.input,
                    background: colors.cardBg,
                    color: colors.text,
                    borderColor: colors.border,
                  }}
                  placeholder="article-url-slug"
                />
              </div>

              <div style={styles.formGroup}>
                <label style={{ ...styles.label, color: colors.text }}>Excerpt</label>
                <input
                  type="text"
                  value={adminForm.excerpt}
                  onChange={(e) => setAdminForm({ ...adminForm, excerpt: e.target.value })}
                  style={{
                    ...styles.input,
                    background: colors.cardBg,
                    color: colors.text,
                    borderColor: colors.border,
                  }}
                  placeholder="Brief summary for homepage"
                />
              </div>

              <div style={styles.formGroup}>
                <label style={{ ...styles.label, color: colors.text }}>SEO Description</label>
                <input
                  type="text"
                  value={adminForm.seoDescription}
                  onChange={(e) => setAdminForm({ ...adminForm, seoDescription: e.target.value })}
                  style={{
                    ...styles.input,
                    background: colors.cardBg,
                    color: colors.text,
                    borderColor: colors.border,
                  }}
                  placeholder="Meta description (50-160 chars)"
                  maxLength={160}
                />
                <small style={{ color: colors.textSecondary }}>{adminForm.seoDescription.length}/160</small>
              </div>

              <div style={styles.formGroup}>
                <label style={{ ...styles.label, color: colors.text }}>Category</label>
                <input
                  type="text"
                  value={adminForm.category}
                  onChange={(e) => setAdminForm({ ...adminForm, category: e.target.value })}
                  style={{
                    ...styles.input,
                    background: colors.cardBg,
                    color: colors.text,
                    borderColor: colors.border,
                  }}
                  placeholder="design, technology, strategy..."
                />
              </div>

              <div style={styles.formGroup}>
                <label style={{ ...styles.label, color: colors.text }}>Content (Markdown) *</label>
                <textarea
                  value={adminForm.content}
                  onChange={(e) => setAdminForm({ ...adminForm, content: e.target.value })}
                  style={{
                    ...styles.textarea,
                    background: colors.cardBg,
                    color: colors.text,
                    borderColor: colors.border,
                  }}
                  placeholder="Write your article (supports markdown)..."
                  rows={15}
                />
              </div>

              <button type="submit" style={styles.publishBtn}>
                {editingId ? 'Update Article' : 'Publish Article'}
              </button>
            </form>

            <div style={styles.adminPosts}>
              <h3 style={{ ...styles.adminSubtitle, color: colors.text }}>Your Articles</h3>
              {posts.length === 0 ? (
                <p style={{ ...styles.empty, color: colors.textSecondary }}>No articles yet</p>
              ) : (
                <div style={styles.adminList}>
                  {posts.map((post) => (
                    <div
                      key={post.id}
                      style={{
                        ...styles.adminPostCard,
                        background: colors.cardBg,
                        borderColor: colors.border,
                      }}
                    >
                      <div>
                        <h4 style={{ margin: '0 0 0.25rem 0', color: colors.text }}>{post.title}</h4>
                        <p style={{ margin: 0, fontSize: '0.85rem', color: colors.textSecondary }}>
                          {formatDate(post.createdAt)}
                        </p>
                      </div>
                      <div style={{ display: 'flex', gap: '0.5rem' }}>
                        <button onClick={() => handleEdit(post)} style={styles.smallBtn}>Edit</button>
                        <button onClick={() => handleDelete(post.id)} style={{ ...styles.smallBtn, background: '#ef4444' }}>Delete</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      <footer style={{ ...styles.footer, borderTopColor: colors.border, color: colors.textSecondary }}>
        <p>© 2024. Professional Blog. Built with React & Node.js</p>
      </footer>
    </div>
  );
};

const styles = {
  container: {
    minHeight: '100vh',
    fontFamily: 'system-ui, -apple-system, sans-serif',
    lineHeight: 1.6,
    transition: 'background 0.3s, color 0.3s',
  },
  header: {
    borderBottom: '1px solid',
    padding: '1.5rem 0',
    position: 'sticky',
    top: 0,
    zIndex: 100,
    transition: 'background 0.3s',
  },
  headerContent: {
    maxWidth: '55rem',
    margin: '0 auto',
    paddingLeft: '1.5rem',
    paddingRight: '1.5rem',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logo: {
    fontSize: '1rem',
    fontWeight: 700,
    cursor: 'pointer',
    background: 'none',
    border: 'none',
  },
  nav: {
    display: 'flex',
    gap: '2rem',
    alignItems: 'center',
  },
  navButton: {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontSize: '0.95rem',
    transition: 'all 0.2s',
    padding: '0.5rem 0',
  },
  themeBtn: {
    border: '1px solid',
    borderRadius: '0.375rem',
    padding: '0.5rem 0.75rem',
    cursor: 'pointer',
    fontSize: '1rem',
    transition: 'all 0.2s',
  },
  main: {
    maxWidth: '55rem',
    margin: '0 auto',
    paddingLeft: '1.5rem',
    paddingRight: '1.5rem',
    paddingTop: '3rem',
    paddingBottom: '3rem',
  },
  homeView: {},
  hero: {
    marginBottom: '4rem',
    textAlign: 'center',
  },
  heroTitle: {
    fontSize: '2.75rem',
    fontWeight: 700,
    margin: '0 0 0.75rem 0',
    lineHeight: 1.15,
    letterSpacing: '-0.02em',
  },
  heroSubtitle: {
    fontSize: '1.15rem',
    margin: 0,
  },
  newsletter: {
    padding: '2rem',
    borderRadius: '0.75rem',
    border: '1px solid',
    marginBottom: '3rem',
  },
  newsletterTitle: {
    fontSize: '1.25rem',
    fontWeight: 600,
    margin: '0 0 0.5rem 0',
  },
  newsletterText: {
    fontSize: '0.95rem',
    margin: '0 0 1rem 0',
  },
  newsletterForm: {
    display: 'flex',
    gap: '0.75rem',
  },
  emailInput: {
    flex: 1,
    padding: '0.75rem 1rem',
    border: '1px solid',
    borderRadius: '0.375rem',
    fontSize: '0.95rem',
  },
  subscribeBtn: {
    background: '#2563eb',
    color: '#fff',
    border: 'none',
    padding: '0.75rem 1.5rem',
    borderRadius: '0.375rem',
    fontWeight: 500,
    cursor: 'pointer',
    transition: 'background 0.2s',
  },
  subscribeMsg: {
    marginTop: '0.5rem',
    fontSize: '0.9rem',
  },
  postList: {
    marginTop: '2rem',
  },
  postCard: {
    padding: '1.5rem',
    borderRadius: '0.5rem',
    border: '1px solid',
    transition: 'all 0.2s',
  },
  postTitle: {
    fontSize: '1.5rem',
    fontWeight: 600,
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    textAlign: 'left',
    padding: 0,
    marginBottom: '0.5rem',
    transition: 'opacity 0.2s',
  },
  postMeta: {
    fontSize: '0.9rem',
    marginBottom: '0.75rem',
  },
  category: {
    padding: '0.25rem 0.75rem',
    borderRadius: '0.25rem',
    fontSize: '0.85rem',
    fontWeight: 500,
  },
  postExcerpt: {
    margin: 0,
  },
  fullPost: {
    maxWidth: '50rem',
  },
  postHeader: {
    marginBottom: '2rem',
    paddingBottom: '2rem',
    borderBottom: '1px solid',
  },
  postFullTitle: {
    fontSize: '2.5rem',
    fontWeight: 700,
    margin: '0 0 1rem 0',
    lineHeight: 1.15,
    letterSpacing: '-0.02em',
  },
  postContent: {
    fontSize: '1rem',
    lineHeight: 1.8,
  },
  adminView: {
    maxWidth: '50rem',
  },
  adminTitle: {
    fontSize: '1.75rem',
    fontWeight: 600,
    margin: '0 0 2rem 0',
  },
  form: {
    marginBottom: '3rem',
  },
  formGroup: {
    marginBottom: '1.5rem',
  },
  label: {
    display: 'block',
    fontSize: '0.9rem',
    fontWeight: 500,
    marginBottom: '0.5rem',
  },
  input: {
    width: '100%',
    padding: '0.75rem',
    border: '1px solid',
    borderRadius: '0.375rem',
    fontSize: '0.95rem',
    boxSizing: 'border-box',
    transition: 'all 0.2s',
  },
  textarea: {
    width: '100%',
    padding: '0.75rem',
    border: '1px solid',
    borderRadius: '0.375rem',
    fontSize: '0.95rem',
    fontFamily: 'monospace',
    boxSizing: 'border-box',
    resize: 'vertical',
    transition: 'all 0.2s',
  },
  publishBtn: {
    background: '#2563eb',
    color: '#fff',
    border: 'none',
    padding: '0.75rem 1.5rem',
    borderRadius: '0.375rem',
    fontSize: '0.95rem',
    fontWeight: 500,
    cursor: 'pointer',
    transition: 'background 0.2s',
  },
  adminSubtitle: {
    fontSize: '1.1rem',
    fontWeight: 600,
    margin: '2rem 0 1rem 0',
  },
  adminPosts: {
    marginTop: '3rem',
  },
  adminList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.75rem',
  },
  adminPostCard: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '1rem',
    borderRadius: '0.375rem',
    borderLeft: '3px solid #2563eb',
    border: '1px solid',
  },
  smallBtn: {
    background: '#6366f1',
    color: '#fff',
    border: 'none',
    padding: '0.5rem 0.75rem',
    borderRadius: '0.25rem',
    fontSize: '0.8rem',
    cursor: 'pointer',
    transition: 'background 0.2s',
  },
  loading: {
    textAlign: 'center',
  },
  empty: {
    textAlign: 'center',
  },
  footer: {
    textAlign: 'center',
    padding: '2rem 1.5rem',
    fontSize: '0.9rem',
    borderTop: '1px solid',
  },
};

export default ProfessionalBlog;
