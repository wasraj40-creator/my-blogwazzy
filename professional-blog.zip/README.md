# Professional Blog

A modern, professional blog with dark mode, markdown support, and SEO optimization built with React and Node.js.

## Features

✅ Dark mode toggle  
✅ Markdown post support  
✅ SEO optimized (sitemap, meta tags)  
✅ Newsletter signup  
✅ Admin panel to create/edit posts  
✅ Responsive design  

## Quick Start

### Backend Setup

```bash
npm install
npm start
```

Backend runs on `http://localhost:5000`

### Frontend Setup

```bash
# In a new terminal/folder
npx create-react-app blog-frontend
cd blog-frontend
npm install react-markdown
# Replace src/App.js with Blog-Professional.jsx
npm start
```

Frontend runs on `http://localhost:3000`

## Files

- `server-professional.js` - Backend API server
- `Blog-Professional.jsx` - React frontend component
- `package.json` - Node dependencies
- `.gitignore` - Git ignore rules

## Deployment

See SETUP-PROFESSIONAL.md for detailed deployment instructions for Vercel & Railway.

## API Endpoints

```
GET    /api/posts              - Get all posts
GET    /api/posts/:slug        - Get single post
POST   /api/posts              - Create post
PUT    /api/posts/:id          - Update post
DELETE /api/posts/:id          - Delete post
GET    /sitemap.xml            - SEO sitemap
```

## Technologies

- React (frontend)
- Express.js (backend)
- SQLite (database)
- React Markdown (rendering)

Built with ❤️
